"use client"

import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { FileText, Lock } from "lucide-react"
import BackgroundPaths from "@/components/kokonutui/background-paths"
import { motion } from "framer-motion"

export default function HomePage() {
  const router = useRouter()

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      <BackgroundPaths title="NS Document" />

      <div className="relative z-10 container mx-auto px-4 flex-1 flex flex-col items-center justify-center">
        <motion.div
          className="text-center mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-2xl font-bold mb-4 text-foreground">Système de Documents Sécurisés</h2>

          <p className="text-lg text-muted-foreground mb-8 max-w-md mx-auto">
            Accédez au document sécurisé NS avec notre système de protection avancée
          </p>

          <motion.div whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.98 }} className="inline-block">
            <Button
              size="lg"
              onClick={() => router.push("/secure-document")}
              className="bg-primary hover:bg-primary/90 text-primary-foreground group"
            >
              <FileText className="mr-2 h-5 w-5" />
              <span>Voir le document NS</span>
              <Lock className="ml-2 h-4 w-4 opacity-70 group-hover:opacity-100 transition-opacity" />
            </Button>
          </motion.div>
        </motion.div>
      </div>
    </div>
  )
}

